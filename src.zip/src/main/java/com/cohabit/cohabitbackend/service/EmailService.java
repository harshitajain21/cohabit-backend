package com.cohabit.cohabitbackend.service;

import com.cohabit.cohabitbackend.model.User;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;
import org.springframework.web.util.UriComponentsBuilder;

/**
 * Sends transactional authentication emails for Cohabit accounts.
 */
@Service
public class EmailService {

    private final JavaMailSender javaMailSender;
    private final String fromAddress;
    private final String verificationBaseUrl;

    /**
     * Creates an email service backed by Spring's JavaMailSender.
     *
     * @param javaMailSender configured mail sender
     * @param fromAddress sender address for outbound emails
     * @param verificationBaseUrl public verification endpoint URL
     */
    public EmailService(
            JavaMailSender javaMailSender,
            @Value("${cohabit.mail.from:no-reply@cohabit.local}") String fromAddress,
            @Value("${cohabit.auth.verification-base-url:http://localhost:8080/auth/verify}") String verificationBaseUrl
    ) {
        this.javaMailSender = javaMailSender;
        this.fromAddress = fromAddress;
        this.verificationBaseUrl = verificationBaseUrl;
    }

    /**
     * Sends an account verification email to a newly registered user.
     *
     * @param user recipient user
     * @param token verification token
     */
    public void sendVerificationEmail(User user, String token) {
        String verificationUrl = UriComponentsBuilder.fromUriString(verificationBaseUrl)
                .queryParam("token", token)
                .build()
                .toUriString();

        SimpleMailMessage message = new SimpleMailMessage();
        message.setFrom(fromAddress);
        message.setTo(user.getIitEmail());
        message.setSubject("Verify your Cohabit account");
        message.setText("""
                Hi %s,

                Verify your Cohabit account using this link:
                %s

                This link expires soon. If you did not create a Cohabit account, ignore this email.
                """.formatted(user.getName(), verificationUrl));

        javaMailSender.send(message);
    }

    /**
     * Sends a friend request notification email.
     *
     * @param requester user who sent the friend request
     * @param recipient user who receives the friend request
     */
    public void sendFriendRequestEmail(User requester, User recipient) {
        SimpleMailMessage message = new SimpleMailMessage();
        message.setFrom(fromAddress);
        message.setTo(recipient.getIitEmail());
        message.setSubject("New Cohabit friend request");
        message.setText("""
                Hi %s,

                %s sent you a friend request on Cohabit.

                Sign in to Cohabit to accept the request and view compatibility once both questionnaires are complete.
                """.formatted(recipient.getName(), requester.getName()));

        javaMailSender.send(message);
    }
}
